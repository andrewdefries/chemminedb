#define PORT            1477
#define JOBS_AT_A_TIME 2000

int refill(const char* host, char** s1, char** s2);
