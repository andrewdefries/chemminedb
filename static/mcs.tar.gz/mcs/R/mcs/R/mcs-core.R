# This is an automatically generated file by the R module for SWIG.

##   Generated via the command line invocation:
##	 swig -module mcs -o mcs/src/r_wrap.c -r ../swig.i


#                         srun.swg                            #
#
# This is the basic code that is needed at run time within R to
# provide and define the relevant classes.  It is included
# automatically in the generated code by copying the contents of
# srun.swg into the newly created binding code.


# This could be provided as a separate run-time library but this
# approach allows the code to to be included directly into the
# generated bindings and so removes the need to have and install an
# additional library.  We may however end up with multiple copies of
# this and some confusion at run-time as to which class to use. This
# is an issue when we use NAMESPACES as we may need to export certain
# classes.

######################################################################

if(length(getClassDef("RSWIGStruct")) == 0) 
  setClass("RSWIGStruct", representation("VIRTUAL"))



if(length(getClassDef("ExternalReference")) == 0) 
# Should be virtual but this means it loses its slots currently
#representation("VIRTUAL")
  setClass("ExternalReference", representation( ref = "externalptr"))



if(length(getClassDef("NativeRoutinePointer")) == 0) 
  setClass("NativeRoutinePointer", 
              representation(parameterTypes = "character",
                             returnType = "character",
                             "VIRTUAL"), 
              contains = "ExternalReference")

if(length(getClassDef("CRoutinePointer")) == 0) 
  setClass("CRoutinePointer", contains = "NativeRoutinePointer")


if(length(getClassDef("EnumerationValue")) == 0) 
  setClass("EnumerationValue", contains = "integer")


if(!isGeneric("copyToR")) 
 setGeneric("copyToR",
            function(value, obj = new(gsub("Ref$", "", class(value)))) 
               standardGeneric("copyToR"
           ))

setGeneric("delete", function(obj) standardGeneric("delete"))


SWIG_createNewRef = 
function(className, ..., append = TRUE)
{
  f = get(paste("new", className, sep = "_"), mode = "function")

  f(...)
}

if(!isGeneric("copyToC")) 
 setGeneric("copyToC", 
             function(value, obj = RSWIG_createNewRef(class(value)))
              standardGeneric("copyToC"
            ))


# 
defineEnumeration =
function(name, .values, where = topenv(parent.frame()), suffix = "Value")
{
   # Mirror the class definitions via the E analogous to .__C__
  defName = paste(".__E__", name, sep = "")
  assign(defName,  .values,  envir = where)

  if(nchar(suffix))
    name = paste(name, suffix, sep = "")

  setClass(name, contains = "EnumerationValue", where = where)
}

enumToInteger <- function(name,type)
{
   if (is.character(name)) {
   ans <- as.integer(get(paste(".__E__", type, sep = ""))[name])
   if (is.na(ans)) {warning("enum not found ", name, " ", type)}
   ans
   } 
}

enumFromInteger =
function(i,type)
{
  itemlist <- get(paste(".__E__", type, sep=""))
  names(itemlist)[match(i, itemlist)]
}

coerceIfNotSubclass =
function(obj, type) 
{
    if(!is(obj, type)) {as(obj, type)} else obj
}


setClass("SWIGArray", representation(dims = "integer"), contains = "ExternalReference")

setMethod("length", "SWIGArray", function(x) x@dims[1])


defineEnumeration("SCopyReferences",
                   .values = c( "FALSE" = 0, "TRUE" = 1, "DEEP" = 2))

assert = 
function(condition, message = "")
{
  if(!condition)
    stop(message)

  TRUE
}


if(FALSE) {
print.SWIGFunction =
function(x, ...)
 {
 }
}


#######################################################################

R_SWIG_getCallbackFunctionStack =
function()
{
    # No PACKAGE argument as we don't know what the DLL is.
  .Call("R_SWIG_debug_getCallbackFunctionData")
}

R_SWIG_addCallbackFunctionStack =
function(fun, userData = NULL)
{
    # No PACKAGE argument as we don't know what the DLL is.
  .Call("R_SWIG_R_pushCallbackFunctionData", fun, userData)
}


#######################################################################





setMethod('[', "ExternalReference",
function(x,i,j, ..., drop=TRUE) 
if (!is.null(x$"__getitem__")) 
sapply(i, function(n) x$"__getitem__"(i=as.integer(n-1))))

setMethod('[<-' , "ExternalReference",
function(x,i,j, ..., value) 
if (!is.null(x$"__setitem__")) {
sapply(1:length(i), function(n) 
x$"__setitem__"(i=as.integer(i[n]-1), x=value[n]))
x
})

setAs('ExternalReference', 'character',
function(from) {if (!is.null(from$"__str__")) from$"__str__"()})

setMethod('print', 'ExternalReference',
function(x) {print(as(x, "character"))})

# Start of max

`max` = function(graph1, graph2, mc, user_bound, long_result, .copy = FALSE)
{
  graph1 = coerceIfNotSubclass(graph1, "_p__Graph") 
  graph2 = coerceIfNotSubclass(graph2, "_p__Graph") 
  mc = as.integer(mc) 
  
  if(length(mc) > 1) {
    Rf_warning("using only the first element of mc")
  }
  
  user_bound = as.integer(user_bound) 
  
  if(length(user_bound) > 1) {
    Rf_warning("using only the first element of user_bound")
  }
  
  long_result = as.integer(long_result) 
  
  if(length(long_result) > 1) {
    Rf_warning("using only the first element of long_result")
  }
  
  .Call('R_swig_max', graph1, graph2, mc, user_bound, long_result, as.logical(.copy), PACKAGE='mcs')
  
}

attr(`max`, 'returnType') = 'numeric'
attr(`max`, "inputTypes") = c('_p__Graph', '_p__Graph', 'numeric', 'numeric', 'numeric')
class(`max`) = c("SWIGFunction", class('max'))

# Start of read_graph

`read_graph` = function(filename, .copy = FALSE)
{
  filename = as(filename, "character") 
  ans = .Call('R_swig_read_graph', filename, as.logical(.copy), PACKAGE='mcs')
  class(ans) <- "_p__Graph"
  
  ans
  
}

attr(`read_graph`, 'returnType') = '_p__Graph'
attr(`read_graph`, "inputTypes") = c('character')
class(`read_graph`) = c("SWIGFunction", class('read_graph'))

# Start of parse_sdf

`parse_sdf` = function(sdf, .copy = FALSE)
{
  sdf = as(sdf, "character") 
  ans = .Call('R_swig_parse_sdf', sdf, as.logical(.copy), PACKAGE='mcs')
  class(ans) <- "_p__Graph"
  
  ans
  
}

attr(`parse_sdf`, 'returnType') = '_p__Graph'
attr(`parse_sdf`, "inputTypes") = c('character')
class(`parse_sdf`) = c("SWIGFunction", class('parse_sdf'))

# Start of get_best

`get_best` = function(graph_id, index, .copy = FALSE)
{
  graph_id = as.integer(graph_id) 
  
  if(length(graph_id) > 1) {
    Rf_warning("using only the first element of graph_id")
  }
  
  index = as.integer(index) 
  
  if(length(index) > 1) {
    Rf_warning("using only the first element of index")
  }
  
  ans = .Call('R_swig_get_best', graph_id, index, as.logical(.copy), PACKAGE='mcs')
  class(ans) <- "_p_short"
  
  ans
  
}

attr(`get_best`, 'returnType') = '_p_short'
attr(`get_best`, "inputTypes") = c('numeric', 'numeric')
class(`get_best`) = c("SWIGFunction", class('get_best'))

# Start of is_null

`is_null` = function(g, .copy = FALSE)
{
  g = coerceIfNotSubclass(g, "_p__Graph") 
  .Call('R_swig_is_null', g, as.logical(.copy), PACKAGE='mcs')
  
}

attr(`is_null`, 'returnType') = 'numeric'
attr(`is_null`, "inputTypes") = c('_p__Graph')
class(`is_null`) = c("SWIGFunction", class('is_null'))

# Start of set_timeout

`set_timeout` = function(time)
{
  time = as.integer(time) 
  
  if(length(time) > 1) {
    Rf_warning("using only the first element of time")
  }
  
  .Call('R_swig_set_timeout', time, PACKAGE='mcs')
  
}

attr(`set_timeout`, 'returnType') = 'void'
attr(`set_timeout`, "inputTypes") = c('numeric')
class(`set_timeout`) = c("SWIGFunction", class('set_timeout'))


