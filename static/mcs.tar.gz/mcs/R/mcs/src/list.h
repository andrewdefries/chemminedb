#ifndef __LIST_C
extern short EOL_ELEMENT, DEL_ELEMENT, CROSSED_ELEMENT, NONE;
#endif

#ifndef __LIST_H
#define __LIST_H
#include <stdlib.h>


/* is current position the end of list ? */
#define EOL(x) ((x) == EOL_ELEMENT)
/* does current position contain a None object */
#define NA(x) ((x) == DEL_ELEMENT)

/* an interator-style function, for use with while(.) to iterate over all
 * elements in a list and execute the while-loop body */
#define FOREACH(x)	for (short *pp = NULL, *p = foreach((x), &pp); \
													p != NULL; \
													p = foreach((x), &pp))

short* foreach(short*, short**);
inline short* makelist(int, short);
inline int len(short*);
inline void append(short*, short);
inline short* find(short*, short);
inline short* del(short*, short);
inline void cross(short*);
inline short* copy(short*);
void print(short*);

#endif
